# ZAPATA — Página web gratuita

## Archivos
- index.html: página principal.
- style.css: diseño y estilos.

## Antes de publicarla
En `index.html`, cambia:
1. `57TU_NUMERO` por el número de WhatsApp con código de país, sin + ni espacios.
2. `TU_USUARIO` por el usuario de Instagram.
3. Los nombres, descripciones y precios de los productos.
4. Los bloques `FOTO 01`, etc. por tus fotos reales.

## Publicarla gratis con GitHub Pages
1. Crea una cuenta en GitHub.
2. Crea un repositorio nuevo.
3. Sube `index.html` y `style.css`.
4. En Settings > Pages, selecciona publicar desde la rama principal (main).
5. GitHub te dará una dirección gratuita para compartir.

También puedes usar Google Sites si prefieres no tocar código.
